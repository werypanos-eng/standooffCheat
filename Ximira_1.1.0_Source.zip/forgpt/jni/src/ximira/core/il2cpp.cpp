
// ================================================================================
// Community links:
// - @imguisource_bot
// - @ImGui_Source_FIXNEY (ImGui Source)
// - @il2cpp_src (shit src 🧨)
// ================================================================================

#include "ximira/core/il2cpp.h"
#include "ximira/core/memory.h"
#include "game/offsets.hpp"
#include "ximira/util/log.h"

#include <dlfcn.h>
#include <cstring>
#include <mutex>
#include <link.h>
#include <array>
#include <string>
#include <unordered_map>

namespace xim::il2cpp {

using namespace lemming::offsets::il2cpp_api;

// ---- typedefs, соответствующие il2cpp-api.h ----
using t_domain_get          = void* (*)();
using t_domain_assembly_open= void* (*)(void*, const char*);
using t_assembly_get_image  = void* (*)(void*);
using t_class_from_name     = void* (*)(void*, const char*, const char*);
using t_class_get_method_from_name = void* (*)(void*, const char*, int);
using t_class_get_field_from_name  = void* (*)(void*, const char*);
using t_field_get_offset    = std::size_t (*)(void*);
using t_class_get_name      = const char* (*)(void*);
using t_class_get_namespace = const char* (*)(void*);
using t_class_get_parent    = void* (*)(void*);

static t_domain_get                 p_domain_get = nullptr;
static t_domain_assembly_open       p_domain_assembly_open = nullptr;
static t_assembly_get_image         p_assembly_get_image = nullptr;
static t_class_from_name            p_class_from_name = nullptr;
static t_class_get_method_from_name p_class_get_method_from_name = nullptr;
static t_class_get_field_from_name  p_class_get_field_from_name = nullptr;
static t_field_get_offset           p_field_get_offset = nullptr;
static t_class_get_name             p_class_get_name = nullptr;
static t_class_get_namespace        p_class_get_namespace = nullptr;
static t_class_get_parent           p_class_get_parent = nullptr;

static uintptr_t g_unity_base = 0;
static std::mutex g_init_mutex;
static bool g_ok = false;

// ---- helpers ----

// The supplied ARM64 APK embeds IL2CPP into libunity.so.
static uintptr_t find_unity_base() {
    uintptr_t result=0;
    dl_iterate_phdr([](dl_phdr_info* info,size_t,void* out)->int {
        if(!info->dlpi_name||!std::strstr(info->dlpi_name,"libunity.so"))return 0;
        const auto base=static_cast<uintptr_t>(info->dlpi_addr);
        const std::array<unsigned char,24> expected{4,0,0,0,8,0,0,0,3,0,0,0,'G','N','U',0,0x69,0x81,0x5f,0x2b,0xef,0xe1,0x35,0xc2};
        std::array<unsigned char,24> actual{};
        if(mem::read(base+0x270,actual)&&actual==expected){*static_cast<uintptr_t*>(out)=base;return 1;}
        return 0;
    },&result);
    return result;
}
static void* resolve_sym(const char* name,uintptr_t fallback_off) {
    static void* handle=nullptr;
    if(!handle)handle=dlopen("libunity.so",RTLD_NOLOAD|RTLD_NOW);
    if(handle)if(void* sym=dlsym(handle,name))return sym;
    if(g_unity_base&&fallback_off>=lemming::offsets::elf::kTextBegin&&fallback_off<lemming::offsets::elf::kTextEnd)
        return reinterpret_cast<void*>(g_unity_base+fallback_off);
    return nullptr;
}

// ---- init ----

bool init() {
    std::lock_guard<std::mutex> initLock(g_init_mutex);
    if(g_ok)return true;
    {
        g_unity_base = find_unity_base();
        if (!g_unity_base) {
            // il2cpp может быть ещё не загружен — не паникуем, попробуем позже
            return false;
        }

        p_domain_get = reinterpret_cast<t_domain_get>(
                resolve_sym("il2cpp_domain_get", kDomainGet));
        p_domain_assembly_open = reinterpret_cast<t_domain_assembly_open>(
                resolve_sym("il2cpp_domain_assembly_open", kDomainAssemblyOpen));
        p_assembly_get_image = reinterpret_cast<t_assembly_get_image>(
                resolve_sym("il2cpp_assembly_get_image", kAssemblyGetImage));
        p_class_from_name = reinterpret_cast<t_class_from_name>(
                resolve_sym("il2cpp_class_from_name", kClassFromName));
        p_class_get_method_from_name = reinterpret_cast<t_class_get_method_from_name>(
                resolve_sym("il2cpp_class_get_method_from_name", kClassGetMethodFromName));
        p_class_get_field_from_name = reinterpret_cast<t_class_get_field_from_name>(
                resolve_sym("il2cpp_class_get_field_from_name", kClassGetFieldFromName));
        p_field_get_offset = reinterpret_cast<t_field_get_offset>(
                resolve_sym("il2cpp_field_get_offset", kFieldGetOffset));
        p_class_get_name = reinterpret_cast<t_class_get_name>(
                resolve_sym("il2cpp_class_get_name", kClassGetName));
        p_class_get_namespace = reinterpret_cast<t_class_get_namespace>(
                resolve_sym("il2cpp_class_get_namespace", kClassGetNamespace));
        p_class_get_parent = reinterpret_cast<t_class_get_parent>(
                resolve_sym("il2cpp_class_get_parent", kClassGetParent));

        g_ok = p_domain_get && p_domain_assembly_open && p_assembly_get_image
               && p_class_from_name && p_class_get_field_from_name
               && p_field_get_offset && p_class_get_method_from_name;
    }
    return g_ok;
}

// ---- wrappers ----

void* domain_get() {
    return p_domain_get ? p_domain_get() : nullptr;
}

void* domain_assembly_open(const char* name) {
    void* d = domain_get();
    if (!d || !p_domain_assembly_open) return nullptr;
    return p_domain_assembly_open(d, name);
}

void* assembly_get_image(void* assembly) {
    return (assembly && p_assembly_get_image) ? p_assembly_get_image(assembly) : nullptr;
}

void* class_from_name(void* image, const char* ns, const char* name) {
    if (!image || !p_class_from_name) return nullptr;

    // кэш по (image, ns, name) — убираем O(n) поиск в hot path
    static std::unordered_map<std::string, void*> cache;
    // ключ склеиваем из адреса image и хэша строк — простая, но рабочая схема
    static std::mutex mtx;
    std::lock_guard lk(mtx);
    char keybuf[256];
    snprintf(keybuf, sizeof(keybuf), "%p|%s|%s", image, ns ? ns : "", name);
    auto it = cache.find(keybuf);
    if (it != cache.end()) return it->second;

    void* k = p_class_from_name(image, ns, name);
    // кэшируем только успешные резолвы
    if (k) cache[keybuf] = k;
    return k;
}

void* class_get_method(void* klass, const char* name, int argc) {
    return (klass && p_class_get_method_from_name)
           ? p_class_get_method_from_name(klass, name, argc) : nullptr;
}

void* class_get_field(void* klass, const char* name) {
    return (klass && p_class_get_field_from_name)
           ? p_class_get_field_from_name(klass, name) : nullptr;
}

size_t field_get_offset(void* field) {
    return (field && p_field_get_offset) ? p_field_get_offset(field) : 0;
}

void* class_get_parent(void* klass) {
    return (klass && p_class_get_parent) ? p_class_get_parent(klass) : nullptr;
}

const char* class_get_name(void* klass) {
    return (klass && p_class_get_name) ? p_class_get_name(klass) : "";
}

} // namespace xim::il2cpp