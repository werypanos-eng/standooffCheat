#include "ximira/features/world_mod/world_mod.h"
#include "ximira/features/world_mod/bindings_110.h"
#include "features/visuals/esp_runtime.hpp"
#include "ximira/util/log.h"
#include <array>
#include <mutex>
#include <cstring>
#include <cmath>

namespace xim::features::world_mod {
namespace {
namespace ed = lemming::esp::detail;
struct Color {float r,g,b,a;};
static_assert(sizeof(Color)==16,"Unity Color ABI");
WorldCfg g_cfg{},g_pending{};
std::mutex g_pendingMutex;
std::atomic<bool> g_requested{false};
std::uint64_t g_generation=0,g_appliedGeneration=0;
std::uintptr_t g_base=0;
void* g_world=nullptr;
std::array<std::uintptr_t,16> g_functions{};
bool g_ready=false,g_fogSaved=false,g_ambientSaved=false,g_fogApplied=false,g_ambientApplied=false;
struct OriginalFog {bool enabled;int mode;float density,start,end;Color color;} g_fog{};
struct OriginalAmbient {float intensity;Color color;} g_ambient{};

template<class Fn> Fn fn(unsigned index){return reinterpret_cast<Fn>(g_functions[index]);}
using GetBool=bool(*)(const void*);using SetBool=void(*)(bool,const void*);
using GetInt=int(*)(const void*);using SetInt=void(*)(int,const void*);
using GetFloat=float(*)(const void*);using SetFloat=void(*)(float,const void*);
using ColorCall=void(*)(Color*,const void*);
float bounded(float v,float lo,float hi,float fallback){return std::isfinite(v)?std::clamp(v,lo,hi):fallback;}
Color color(const float v[4]){return {bounded(v[0],0,1,0.5f),bounded(v[1],0,1,0.5f),bounded(v[2],0,1,0.5f),bounded(v[3],0,1,1.f)};}

bool resolve() {
    const auto base=ed::g_runtime.unityBase;
    if(!base)return false;
    if(g_ready&&g_base==base)return true;
    const std::array<unsigned char,24> wanted{4,0,0,0,8,0,0,0,3,0,0,0,'G','N','U',0,0x69,0x81,0x5f,0x2b,0xef,0xe1,0x35,0xc2};
    std::array<unsigned char,24> actual{};
    if(!ed::readValue(reinterpret_cast<void*>(base+0x270),actual)||actual!=wanted)return false;
    for(unsigned i=0;i<16;++i){
        const auto& e=binding::entries[i];std::array<unsigned char,16> bytes{};
        if(e.rva<lemming::offsets::elf::kTextBegin||e.rva>=lemming::offsets::elf::kTextEnd||
           !ed::readValue(reinterpret_cast<void*>(base+e.rva),bytes)||bytes!=e.prologue){
            XWARN("world_mod: signature mismatch at binding %u",i);return false;
        }
        g_functions[i]=base+e.rva;
    }
    g_base=base;g_ready=true;XLOG("world_mod: 1.1.0 native bindings verified");return true;
}
void applyFog(const FogCfg& c){
    if(c.enabled){
        if(!g_fogSaved){g_fog.enabled=fn<GetBool>(0)(nullptr);g_fog.mode=fn<GetInt>(2)(nullptr);g_fog.density=fn<GetFloat>(4)(nullptr);g_fog.start=fn<GetFloat>(6)(nullptr);g_fog.end=fn<GetFloat>(8)(nullptr);fn<ColorCall>(10)(&g_fog.color,nullptr);g_fogSaved=true;}
        Color col=color(c.color);float start=bounded(c.start,0,5000,20),end=bounded(c.end,start+0.1f,10000,200);
        fn<SetBool>(1)(true,nullptr);fn<SetInt>(3)(std::clamp(c.mode,0,2)+1,nullptr);fn<SetFloat>(5)(bounded(c.density,0,1,0.2f),nullptr);fn<SetFloat>(7)(start,nullptr);fn<SetFloat>(9)(end,nullptr);fn<ColorCall>(11)(&col,nullptr);g_fogApplied=true;
    }else if(g_fogApplied&&g_fogSaved){
        fn<SetBool>(1)(g_fog.enabled,nullptr);fn<SetInt>(3)(g_fog.mode,nullptr);fn<SetFloat>(5)(g_fog.density,nullptr);fn<SetFloat>(7)(g_fog.start,nullptr);fn<SetFloat>(9)(g_fog.end,nullptr);fn<ColorCall>(11)(&g_fog.color,nullptr);g_fogApplied=false;g_fogSaved=false;
    }
}
void applyAmbient(const AmbientCfg& c){
    if(c.enabled){
        if(!g_ambientSaved){g_ambient.intensity=fn<GetFloat>(12)(nullptr);fn<ColorCall>(14)(&g_ambient.color,nullptr);g_ambientSaved=true;}
        Color col=color(c.color);fn<SetFloat>(13)(bounded(c.intensity,0,3,1),nullptr);fn<ColorCall>(15)(&col,nullptr);g_ambientApplied=true;
    }else if(g_ambientApplied&&g_ambientSaved){fn<SetFloat>(13)(g_ambient.intensity,nullptr);fn<ColorCall>(15)(&g_ambient.color,nullptr);g_ambientApplied=false;g_ambientSaved=false;}
}
}
WorldCfg& config(){return g_cfg;}
void publish(){
    std::lock_guard<std::mutex> lock(g_pendingMutex);
    if(std::memcmp(&g_pending,&g_cfg,sizeof(g_cfg))!=0){g_pending=g_cfg;++g_generation;}
    g_requested.store(g_cfg.fog.enabled||g_cfg.ambient.enabled,std::memory_order_release);
}
bool requested(){return g_requested.load(std::memory_order_acquire);}
bool init(){return ed::isUnityMainCallback()&&resolve();}
void update(void* player){
    if(!ed::isUnityMainCallback())return;
    WorldCfg cfg{};std::uint64_t generation;
    {std::lock_guard<std::mutex> lock(g_pendingMutex);cfg=g_pending;generation=g_generation;}
    void* world=player?ed::readObject(reinterpret_cast<void*>(reinterpret_cast<std::uintptr_t>(player)+lemming::offsets::field::mfc::kWorld)):nullptr;
    if(!world)return;
    bool newWorld=world!=g_world;
    if(newWorld){g_world=world;g_fogSaved=g_ambientSaved=g_fogApplied=g_ambientApplied=false;}
    if(!cfg.fog.enabled&&!cfg.ambient.enabled&&!g_fogApplied&&!g_ambientApplied)return;
    if(!newWorld&&generation==g_appliedGeneration)return;
    if(!resolve())return;
    applyFog(cfg.fog);applyAmbient(cfg.ambient);g_appliedGeneration=generation;
}
}
