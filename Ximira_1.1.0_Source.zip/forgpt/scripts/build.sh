#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to Android NDK r27c}"
cd "$ROOT"
"$ANDROID_NDK_HOME/ndk-build" NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk APP_SUPPORT_FLEXIBLE_PAGE_SIZES=true -j4 "$@"
mkdir -p out/arm64-v8a
cp libs/arm64-v8a/liblemmingrmt.so out/arm64-v8a/liblemmingrmt.so
