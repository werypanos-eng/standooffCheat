"""Static/native verification and host regressions; not an on-device test.
Usage: python3 checks/verify_port_110.py /path/to/dump-and-libunity
"""
from pathlib import Path
import argparse,hashlib,json,re,struct,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('reference',type=Path);ref=p.parse_args().reference
root=Path(__file__).resolve().parents[1];src=root/'jni/src';b=(ref/'libunity.so').read_bytes()
assert b[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',b,18)[0]==183
header=(src/'game/offsets.hpp').read_text()
for key,name in [('kSourceSha256','script.json'),('kDumpCsSha256','dump.cs'),('kIl2CppHeaderSha256','il2cpp.h'),('kStringLiteralSha256','stringliteral.json'),('kLibUnitySha256','libunity.so')]:
    expected=re.search(key+r'\[\] = "([^"]+)"',header)[1]
    assert hashlib.sha256((ref/name).read_bytes()).hexdigest()==expected,name
assert b[0x270:0x288]==bytes.fromhex('040000000800000003000000474e550069815f2befe135c2')
phoff=struct.unpack_from('<Q',b,32)[0];size,count=struct.unpack_from('<HH',b,54);loads=[]
for i in range(count):
    t,f,o,v,_,fs,ms,_=struct.unpack_from('<IIQQQQQQ',b,phoff+i*size)
    if t==1:loads.append((v,v+fs,o,f))
def raw(a,n):
    for lo,hi,o,f in loads:
        if lo<=a and a+n<=hi and f&1:return b[o+a-lo:o+a-lo+n]
    raise AssertionError(hex(a)+' is not executable/file-backed')
script=json.loads((ref/'script.json').read_text());methods={e['Address']:e for e in script['ScriptMethod']};metadata={e['Name']:e['Address'] for e in script['ScriptMetadata']}
cs=(ref/'dump.cs').read_text()
types={'kClientWorld':'ggk','kRegistry':'nba','kStore':'ibc','kNetObject':'wwv','kPlayer':'odq','kTransforms':'mtc','kModel':'bis','kStats':'ydm','kWeaponPart':'uyg','kWeaponInstance':'jrx','kCameraComponent':'yjp'}
esp=(src/'features/visuals/esp_runtime.hpp').read_text()
for key,name in types.items():
    address=int(re.search(r'\b'+key+r'\s*=\s*(0x[\da-fA-F]+)',header)[1],16)
    assert address==metadata[name+'_TypeInfo'],key
    if key!='kCameraComponent':assert 'classFromSlot(offsets::typeinfo::'+key+', "'+name+'")' in esp
    else:assert 'classFromSlot(offsets::typeinfo::kCameraComponent,"yjp")' in (src/'features/aim/runtime.hpp').read_text()
for file in ['camera_methods_110.json','world_methods_110.json']:
    evidence=json.loads((root/'port'/file).read_text())
    for key,item in evidence.items():
        actual=methods[item['Address']]
        assert actual['Name']==item['Name'] and actual['Signature']==item['Signature'],key
        assert raw(item['Address'],16).hex()==item['PrologueHex'],key
# Verify actual camera method guards, not merely the evidence fixture.
runtime=(src/'features/aim/runtime.hpp').read_text();aim=(src/'features/aim/offsets.hpp').read_text()
for key,words in re.findall(r'bytesMatch\(b\+aim_offsets::(kCamera\w+),\{([^}]+)\}\)',runtime):
    a=int(re.search(r'\b'+key+r'=(0x[\da-fA-F]+)',aim)[1],16)
    assert raw(a,16)==struct.pack('<4I',*[int(w,16) for w in words.split(',')])
assert 'private readonly kgd zmyf; // 0x38' in cs
assert 'validateCameraFunctions()' in runtime and 'c.normal.enabled&&!installCamera()' in runtime
# Execute the real profile matcher using a bounded host-memory reader.
core=(src/'core/entry.cpp').read_text();a=core.index('bool unityProfileMatches(');z=core.index('\nint hookModule(',a);matcher=core[a:z]
prefix=r'''#include <array>
#include <cstdint>
#include <cstring>
#include <cassert>
static uintptr_t lo=0,hi=0;
namespace lemming::esp::detail {template<class T>bool readValue(const void* ptr,T& out){auto a=reinterpret_cast<uintptr_t>(ptr);if(a<lo||a>hi||sizeof(T)>hi-a)return false;std::memcpy(&out,ptr,sizeof(T));return true;}}
'''
main=r'''int main(){std::array<unsigned char,0x288>b{};const unsigned char n[]={4,0,0,0,8,0,0,0,3,0,0,0,'G','N','U',0,0x69,0x81,0x5f,0x2b,0xef,0xe1,0x35,0xc2};std::memcpy(b.data()+0x270,n,24);lo=reinterpret_cast<uintptr_t>(b.data());hi=lo+b.size();assert(unityProfileMatches(lo));b[0x280]^=1;assert(!unityProfileMatches(lo));assert(!unityProfileMatches(0));assert(!unityProfileMatches(hi));}'''
with tempfile.TemporaryDirectory() as folder:
    td=Path(folder);cpp=td/'profile.cpp';exe=td/'profile';cpp.write_text(prefix+matcher+main)
    subprocess.run(['g++','-std=c++17',str(cpp),'-o',str(exe)],check=True);subprocess.run([str(exe)],check=True)
    (td/'android').mkdir();(td/'android/log.h').write_text('#define ANDROID_LOG_INFO 4\n#define ANDROID_LOG_WARN 5\n#define ANDROID_LOG_ERROR 6\nextern "C" int __android_log_print(int,const char*,const char*,...);\n')
    cpp=td/'memory.cpp';exe=td/'memory'
    cpp.write_text(r'''#include "ximira/core/memory.h"
#include "features/aim/core.hpp"
#include <sys/mman.h>
#include <unistd.h>
#include <cassert>
int main(){auto n=sysconf(_SC_PAGESIZE);void* p=mmap(nullptr,n,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(p!=MAP_FAILED);assert(xim::mem::is_readable(p,4));assert(xim::mem::is_writable(p,4));int value=42;assert(xim::mem::write(reinterpret_cast<uintptr_t>(p),value));int out=0;assert(xim::mem::read(reinterpret_cast<uintptr_t>(p),out)&&out==42);assert(!xim::mem::is_readable(nullptr,4));assert(mprotect(p,n,PROT_READ)==0);assert(xim::mem::is_readable(p,4));assert(!xim::mem::is_writable(p,4));assert(!xim::mem::write(reinterpret_cast<uintptr_t>(p),value));munmap(p,n);assert(!xim::mem::is_readable(p,4));auto c=lemming::aim::Configuration{};c.normal.enabled=true;c.silent.enabled=true;c.normal.rcs=true;c.normal.noRecoil=true;c.autoFire.enabled=true;lemming::aim::publish(c);auto got=lemming::aim::configuration();assert(got.normal.enabled&&got.silent.enabled);assert(!got.normal.rcs&&!got.normal.noRecoil&&!got.autoFire.enabled);}
''')
    subprocess.run(['g++','-std=c++17','-I',str(src),'-I',str(td),str(cpp),str(src/'ximira/core/memory.cpp'),'-o',str(exe)],check=True);subprocess.run([str(exe)],check=True)
print('PASS: five provenance hashes; ARM64/Build ID; 11 class identities; camera/world names and prologues; camera hook routing; positive/negative runtime profile gate; memory read/write permissions; unported-feature lockout.')
print('LIMIT: static/host tests; no Android runtime or in-game validation.')
